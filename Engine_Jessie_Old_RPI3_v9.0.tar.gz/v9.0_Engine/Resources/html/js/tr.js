moment.locale('tr', {
    months : "Ocak_Şubat_Mart_Nisan_Mayıs_Haziran_Temmuz_Ağustos_Eylül_Ekim_Kasım_Aralık".split("_"),
    monthsShort : "oca._şub._mar._nis._may._haz._tem._ağu._eyl._eki._kas._ara.".split("_"),
    weekdays : "pazartesi_salı_çarşamba_perşembe_cuma_cumartesi_pazar".split("_"),
    weekdaysShort : "pzt._sa._çrş._prş._cum._cmt._pzr.".split("_"),
    weekdaysMin : "Pt_Sa_Çş_Pş_Cu_Ct_Pz".split("_")
});


