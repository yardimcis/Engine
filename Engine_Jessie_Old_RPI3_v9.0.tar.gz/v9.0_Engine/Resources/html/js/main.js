var parameter = 
{
  // Backend URL, string.
  // 'http://backend.address.com' or '' if backend is the same as frontend
  backendUrl: '',
};

var timeoutCalculated;
var querytime;
var lastquerytime;
var xmlDoc=null;
var xmlDocLang=null;
var xmlDocSource=null;
var xmlDocImgProc=null;
var xmlDocMean=null;
var languageType=null;
var webPort=null;
var mean=null;
var cameraType=null;
var isAutoCalibStage=false;
var restartTime=0;
var rebootTime=0;
var isInRebootState=false;
var is3D = true;
var isRebootNecessary = false;

function ConfigureAutoCalibRelated() 
{
    var url = window.location.href;
	if(url.includes("?next"))
	{
		isAutoCalibStage = true;
		$('.non_auto_calib').hide();
	}
	else
		$('.auto_calib').hide();
}

function getLanguageFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/Language.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("Root");
		languageType = x[0].getElementsByTagName("Language")[0].childNodes[0].nodeValue;
		return	languageType;		
	}
}
function getPortFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/WebServer.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("HTTPS");
		webPort = x[0].getElementsByTagName("Port")[0].childNodes[0].nodeValue;
		return	webPort;		
	}
}
function getMeanFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/ImageProcessing.xml",false);
	xmlhttp.send();
	xmlDocMean=xmlhttp.responseXML;
	if (xmlDocMean!=null)
	{
		xmlDocMean.async=false;
		var x=xmlDocMean.getElementsByTagName("Root");
		mean = x[0].getElementsByTagName("Mean")[0].childNodes[0].nodeValue;
		return	mean;		
	}
}

function getCameraTypeFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/Source.xml",false);
	xmlhttp.send();
	xmlDocSource=xmlhttp.responseXML;
	if (xmlDocSource!=null)
	{
		xmlDocSource.async=false;
		var x=xmlDocSource.getElementsByTagName("Camera1");
		cameraType = x[0].getElementsByTagName("Type")[0].childNodes[0].nodeValue;	
	}
}

function getCountingAlgorithmFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/ImageProcessing.xml",false);
	xmlhttp.send();
	xmlDocImgProc=xmlhttp.responseXML;
	if (xmlDocImgProc!=null)
	{
		xmlDocImgProc.async=false;
		var x=xmlDocImgProc.getElementsByTagName("Root");
		var countingAlgorithm = x[0].getElementsByTagName("CountingAlgorithm")[0].childNodes[0].nodeValue;	
		if( countingAlgorithm == 0 )
		{
			$('.stereo').hide();
			is3D = false;
		}
		else
		{
			$('.nonstereo').hide();
			is3D = true;
		}
	}
	return is3D;
}

function PrepareLanguageXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp2=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp2=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(languageType == "TR")
		xmlhttp2.open("GET","Settings/LanguageTR.xml",false);
	else
		xmlhttp2.open("GET","Settings/LanguageEN.xml",false);
		
	xmlhttp2.send();
	xmlDocLang=xmlhttp2.responseXML;
	
	xmlDocLang.async=false;
}

$(function(){
    languageType = getLanguageFromXML();
	PrepareLanguageXML();
	
	getCountingAlgorithmFromXML();
	getCameraTypeFromXML();
	if(cameraType != "RaspiCam")
		$('.only_raspicam').hide();
	
	shortcut.add("Ctrl+Shift+F",function() {
		window.open("/ImageProcessing.html");
	});
});
 
 function getLangResult(xmlTag)
 {
	return xmlDocLang.getElementsByTagName(xmlTag)[0].childNodes[0].nodeValue;
 }

function convertHeaderLanguage()
{
	document.getElementById("lang_sys").text = getLangResult("SystemSettings");
	document.getElementById("lang_cnt").text = getLangResult("CountSettings");
	document.getElementById("lang_syscmd").text = getLangResult("SystemCommand");
	document.getElementById("lang_adv").text = getLangResult("AdvancedSettings");
	document.getElementById("lang_tcp").text = getLangResult("Tcp");
	document.getElementById("lang_zone").text = getLangResult("TimeZone");
	document.getElementById("lang_webser").text = getLangResult("WebServer");
	document.getElementById("lang_net").text = getLangResult("Network");
	document.getElementById("lang_worktime").text = getLangResult("WorkTime");
	document.getElementById("lang_trip").text = getLangResult("TripWire");
	document.getElementById("lang_roi").text = getLangResult("ROI");
	if( document.getElementById('lang_imgp') !== null )
		document.getElementById("lang_imgp").text = getLangResult("ImageProcess");
	document.getElementById("lang_cam").text = getLangResult("Camera");
	document.getElementById("lang_mask").text = getLangResult("Mask");
	document.getElementById("lang_live").text = getLangResult("Live");
	document.getElementById("lang_restart").text = getLangResult("Restart");
	document.getElementById("lang_reb").text = getLangResult("Reboot");
	document.getElementById("lang_logout").text = getLangResult("Logout");
	document.getElementById("lang_log").text = getLangResult("Log");
	document.getElementById("lang_sync").text = getLangResult("Sync");
	document.getElementById("lang_video").text = getLangResult("VideoRecord");
	document.getElementById("lang_lang").text = getLangResult("ChooseLang");
	$("#lang_setup_wizard").attr("data-original-title", getLangResult("Wizard"));
	$('.yesButton').html("<div class=\"fa fa-check\"></div> "+getLangResult("ButtonYes"));
	$('.noButton').html("<div class=\"fa fa-times\"></div> "+getLangResult("ButtonNo"));
	$('.please_wait').html(getLangResult("Wait"));
	$('.lang_button_next').html(getLangResult("ButtonNext"));
	$('.lang_button_back').html(getLangResult("ButtonBack"));
	
}
 
function getVersionFromXML()
{
	$('.AutoUpdate').hide(); // for now, it should stay hidden
	var isWifi = false;
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/Environment.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	
	if(xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("Device");
		
		restartTime = x[0].getElementsByTagName("RestartDuration")[0].childNodes[0].nodeValue;
		rebootTime = x[0].getElementsByTagName("RebootDuration")[0].childNodes[0].nodeValue;
		
		var hardwareVersion = x[0].getElementsByTagName("HardwareVersion")[0].childNodes[0].nodeValue;
		var firmwareVersion = x[0].getElementsByTagName("FirmwareVersion")[0].childNodes[0].nodeValue;
		
		document.getElementById("versiyon").innerHTML="VCount Embedded v"+firmwareVersion+"."+hardwareVersion;
		document.getElementById("uptime").innerHTML=x[0].getElementsByTagName("UpTime")[0].childNodes[0].nodeValue;
		
		var results = hardwareVersion.split(".");	

		if((results[1] > 0) && (results[1] % 2 == 0))
			isWifi = true;
		else
			isWifi = false;	
		
		if( window.location.href.includes("TimeInterval.html") || window.location.href.includes("TimeSync.html") )
		{
			if(results[1] > 2) 
				isRebootNecessary = true;
		}
		
		return isWifi;
	}
}
 
$(".send_data").on("click", function() {
	// check form
	if( $("#parameter_form").valid() )	
	{
		var dataver = $('#parameter_form').serialize();	
		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			complete: function() 
			{
				if(!isAutoCalibStage)
				{
					if(!isRebootNecessary)
						parameter.updated( "refresh_page" );
					else
					{
						$('.loading').show();
						setTimeout( "$('.loading').hide(); finish_autocalib(getLangResult(\"RebootConfirm2\")) ;", 3 * 1000 );
					}
				}
				else{
					$('.loading').show();
					
					if(window.location.href.includes("TimeSync.html?next"))
						setTimeout( "$('.loading').hide(); navigate('Height.html?next');", 3 * 1000 );
					else if(window.location.href.includes("Height.html?next") && is3D)
						setTimeout( "$('.loading').hide(); navigate('ROI.html?next1');", 3 * 1000 );
					else if(window.location.href.includes("Height.html?next") && !is3D)
						setTimeout( "$('.loading').hide(); navigate('Mask.html?next');", 3 * 1000 );
					else if(window.location.href.includes("TimeInterval.html?next"))
					{
						setTimeout( "$('.loading').hide(); send_parameters_to_cloud() ;", 3 * 1000 );
					}
				}
			}
		});
	}
	else
	{
		alert_popup("Error",getLangResult("WrongInput")); 
	}
});

function send_parameters_to_cloud()
{
	$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=44",
			complete: function() 
			{				
				finish_autocalib(getLangResult("FinishAutoCalib"));
			}
		});	
}

function finish_autocalib(popupMessage) 
{	
	var newIp="";
	
	$.ajax
	({
		dataType: 'html',
		url: '/data/networkinfo',
		data: '',
		success: function( data ) 
		{				
			var results = data.split("&&");		
			if(results[ 0 ] == "ERROR")
			{
				confirm_popup(popupMessage,"",
					function() {
						isInRebootState = true;
						$.ajax
						({
							dataType: 'json',
							url: '/ajax/get_messages',
							data: "ParameterTreeID=21",
							complete: function() 
							{
								var NavigateFunction;
								NavigateFunction = function() {refresh_all();};
								setTimeout( NavigateFunction, rebootTime * 1000 );
								loadingWait(rebootTime);  
							}
						});
					}
				);
			}
			else
			{
				newIp = results[ 0 ];
				
				confirm_popup(popupMessage,"",
					function() {
						isInRebootState = true;
						$.ajax
						({
							dataType: 'json',
							url: '/ajax/get_messages',
							data: "ParameterTreeID=21",
							complete: function() 
							{
								webPort = getPortFromXML();
								var NavigateFunction;
								NavigateFunction = function() {navigate("https://"+newIp+":"+webPort);};
								setTimeout( NavigateFunction, (rebootTime) * 1000 );
								loadingWait(rebootTime);  
							}
						});
					}
				);
			}
		}
	});
	
}

function get_data( TreeID ) 
{	
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_data',
		data: "ParameterTreeID=" + TreeID,
		success: function( Data ) 
		{
			// clear validation
			$("#parameter_form").validate().resetForm();
			
			// get parameter name list
			var leaf_nodes = get_leaf_nodes( Data.Root, "" );			
			
			// set each item
			for( var i = 0; i < leaf_nodes.length; i++ )
			{
				if(document.getElementById(leaf_nodes[ i ]) !== null)
				{
					document.getElementById(leaf_nodes[ i ]).value = eval( "Data.Root." + leaf_nodes[ i ] );
				}
			}					
		},
		error: function() 
		{					
			alert_popup("Error",getLangResult("ReadFail")); 
			setTimeout(refresh_all(),2000);
		},
	});
}

function get_leaf_nodes( JsonArray, Prefix )
{
	var ret = [];	
	
	$.each( JsonArray, function( key, val ) 
	{
		var NewPrefix = ( Prefix == "" ) ? key : Prefix + "." + key;		
		
		if( typeof( val ) == 'object' )
		{			
			var leaf_nodes_list = get_leaf_nodes( val, NewPrefix );			
			ret = ret.concat( leaf_nodes_list );			
		}
		else
		{
			ret.push( NewPrefix )			
		}
	});
	
	return ret;
}

function GetConnectionStatus()
{
	$.ajax
	({
		dataType: 'html',
		url: '/data/cloudconnected',
		data: '',
		success: function( data ) 
		{		
			if(data == 0)//offline
			{
				$('.cloud-online').hide();
				$('.tcp-online').hide();
				$('.offline').show();
			}
			else if(data == 1)//tcp-online
			{
				$('.cloud-online').hide();
				$('.tcp-online').show();
				$('.offline').hide();
			}
			else if(data == 2)//mqtt-online
			{
				$('.cloud-online').show();
				$('.tcp-online').hide();
				$('.offline').hide();
			}
			else
			{
				$('.cloud-online').hide();
				$('.tcp-online').hide();
				$('.offline').hide();
			}
		},
		error: function() 
		{
		}
	});
}

$(".restart").on("click", function() 
{	
	confirm_popup(getLangResult("RestartConfirm"),"",
        function() {
            $.ajax
			({
				dataType: 'json',
				url: '/ajax/get_messages',
				data: "ParameterTreeID=20",
				complete: function() 
				{	
					webPort = getPortFromXML();
					var directFunction = function() {navigate("https://"+location.hostname+":"+webPort); refresh_all();};
					setTimeout( directFunction, restartTime * 1000 );
					
					loadingWait(restartTime);  
				}
			});
        }
    );
});

$(".reboot").on("click", function() 
{	
	confirm_popup(getLangResult("RebootConfirm"),"",
        function() {
			parameter.updated( "system_reboot" );
        }
    );
});

$(".refresh").on("click", function() 
{	
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=39",
		complete: function() 
		{			
			setTimeout(refresh_current(),200);
		}
	});
		
});

$(".turkish").on("click", function() 
{	

	if(languageType != "TR")
	{//if user tries to set the same language with the active one, do nothing
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=29",
			complete: function() 
			{				
				$('.loading').show();				
				setTimeout( "refresh_all()", 2 * 1000 );
			}
		});	
	}
});

$(".english").on("click", function() 
{	
	if(languageType != "EN")
	{//if user tries to set the same language with the active one, do nothing
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=30",
			complete: function() 
			{			
				$('.loading').show();				
				setTimeout( "refresh_all()", 2 * 1000 );
			}
		});	
	}
});

$(".logout").on("click", function() 
{		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=28",
		complete: function() 
		{
			$('.loading').show();
			setTimeout( "refresh_all()", 2 * 1000 );
		}
	});		
});

$(".new_user_send").on("click", function() 
{	
	var dataver = $('#new_user').serialize();
	
	var queryArray = dataver.split('&'); //i.e. ParameterTreeID=34&NewUserPassword=bb&NewUserPassword2=bb
	var newPass1 = queryArray[1].split('=')[1];
	var newPass2 = queryArray[2].split('=')[1];
	
	if(newPass1 == newPass2)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			complete: function() 
			{
				document.getElementById("waitforreload").innerHTML = getLangResult("Wait")+" "+restartTime+" "+getLangResult("Seconds");
				setTimeout("window.location.reload( true )",restartTime*1000);
			}
		});
	}
	else
	{
		document.getElementById("waitforreload").innerHTML = getLangResult("PassNoMatch");
	}
	
});

$(".tcp_send").on("click" , function() 
{	
	// check form
	if( $("#tcp_settings").valid() )	
	{
		var dataver = $('#tcp_settings').serialize();	
		var dataver_wifi = "&WifiNetwork="+document.getElementById("WifiNetwork").value+"&WifiPassword="+document.getElementById("WifiPassword").value;
		dataver_wifi = dataver_wifi.replace(/ /g, "/SpaceChar/");
		dataver+=dataver_wifi;
		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			complete: function() 
			{
				if( isAutoCalibStage )
				{
					$('.loading').show();
					setTimeout( "$('.loading').hide(); navigate('TimeSync.html?next');", 3 * 1000 );
				}
				else
				{
					confirm_popup(getLangResult("ConfirmText"),"",
						function() {
							parameter.updated( "system_reboot" );
						}
					);
				}
			}
		});
	}
	else
	{
		alert_popup("Error",getLangResult("WrongInput")); 
	}
});


$(".tcp_reset").on("click", function() 
{	
	confirm_popup(getLangResult("TcpReset") + 
						  "\n" +
						  "IP:      192.168.1.26\n" +
						  "Netmask: 255.255.255.0\n" +
						  "Gateway: 192.168.1.10\n","",
		function() {
			$.ajax
			({
				dataType: 'json',
				url: '/ajax/get_messages',
				data: "ParameterTreeID=22",
				complete: function() 
				{	
					webPort = getPortFromXML();
					var NavigateFunction = function() {navigate("https://192.168.1.26:"+webPort)};
					setTimeout( NavigateFunction, rebootTime * 1000 );
					
					loadingWait(rebootTime);  
				}
			});
		}
	);

});

$(".mean").on("click", function() 
{	
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=41",
		complete: function() 
		{			
			$('.loading').show();				
			setTimeout( "refresh_all()", 2 * 1000 );
		}
	});
});

function live_image_annotation_check() {
	if(!isInRebootState)
	{
		$.ajax
		({
			dataType: 'json',
			url: '/ajax/get_data',
			data: "ParameterTreeID=1011",
			success: function(data) 
			{													
				if( data.Root.Annotations != null )
				{
					$.each( data.Root.Annotations, function(key, val) 
					{
						if( (key != "ColoredDepth") && (key != "Tracking") )
						{
							if( val == "true" ) $( "[name=" + key + "]" ).attr( 'checked', true );
							else if( val == "false" ) $( "[name=" + key + "]" ).attr( 'checked', false );	
						}						
					});
				}
				$( "[name=ColoredDepth]" ).attr( 'checked', true );
				$( "[name=Tracking]" ).attr( 'checked', true );
			},
			error: function() 
			{		
				setTimeout(refresh_all(),2000);		
			},
		});	
	}	
}


parameter.updated = function( Action ) 
{		
	if( Action == "refresh_page" )
	{
		$('.loading').show();
		
		setTimeout( "refresh_current()", 3 * 1000 );
	}
	else if( Action == "system_reboot" )
	{
		$.ajax
		({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=21",
			complete: function() 
			{	
				webPort = getPortFromXML();
				var NavigateFunction;
				if($('#IP').length) //If IP field is found, the page is TcpSettings.html
					NavigateFunction = function() {navigate("https://"+$("#IP").val()+":"+webPort);};
				else
					NavigateFunction = function() {refresh_all();};
				setTimeout( NavigateFunction, rebootTime * 1000 );
				
				loadingWait(rebootTime);  
			}
		});
	}
};

function reload_iframe( iframe_id )
{
	document.getElementById( iframe_id ).contentWindow.location.reload( true );
}

function navigate_iframe( iframe_id, newURL )
{
	document.getElementById( iframe_id ).contentWindow.location = newURL;
}

function refresh_current()
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    window.location.reload( true );
}

function refresh_all()
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    top.location.reload( true );
}

function navigate( newUrl )
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    window.location.href = newUrl;
}
