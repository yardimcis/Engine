function readCookie(name) 
{
	var nameEQ = name + "=";
	var ca = document.cookie.split(';');
	for(var i=0;i < ca.length;i++) {
			var c = ca[i];
			while (c.charAt(0)==' ') c = c.substring(1,c.length);
			if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
	}
	return "Cookie bulunamadi";
}

function removeElement(nElement) 
{
	try
	{
		document.getElementById(nElement).parentNode.removeChild(document.getElementById(nElement));
	}catch(e)
	{
	}
}

function switchMain()
{
  var current = readCookie("userlevel");
  if( current == "LowLevel" )
  {
     removeElement( "system_commands" );
	 removeElement( "count_settings" );
	 removeElement( "advanced" );
	 removeElement( "tcp" );
	 removeElement( "log" );
	 removeElement( "live" );
	 removeElement( "humancount" );
	 removeElement( "dailyframe" );
	 removeElement( "upload" );
	 removeElement( "save_config" );
	 removeElement( "reset" );
	 removeElement( "reboot" );
	 removeElement( "kick" );
	 removeElement( "block" );
	 removeElement( "tripwire" );
	 removeElement( "mask" );
	 removeElement( "parameters1006" );
	 removeElement( "parameters1007" );
	 removeElement( "parameters1013" );
	 removeElement( "parameters1014" );
	 removeElement( "parameters1015" );
	 removeElement( "parameters1016" );
	 removeElement( "parameters1019" );
	 removeElement( "allow" );
	 removeElement( "videorecord" );
   }
   else if( current == "MiddleLevel" )
   {
    removeElement( "log" );
	removeElement( "dailyframe" );
	removeElement( "parameters1014" );
	removeElement( "parameters1016" );
	removeElement( "kick" );
	removeElement( "block" );
	removeElement( "allow" );
	removeElement( "videorecord" );
	removeElement( "parameters1005" );
   }
   else if( current == "Admin" )
   {
    removeElement( "log" );
	removeElement( "dailyframe" );
	removeElement( "parameters1014" );
	removeElement( "parameters1016" );
	removeElement( "kick" );
	removeElement( "block" );
	removeElement( "allow" );
	removeElement( "parameters1005" );
   }

}

function hideParameters()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "Admin") )
   { 
    removeElement("row1");
	removeElement("row2");
	removeElement("row3");
	removeElement("row4");
	removeElement("column2");
	removeElement("column3");
	removeElement("starthour1");
	removeElement("endhour1");
	removeElement("starthour");
	removeElement("endhour");
	removeElement("setcount");
	removeElement("NumberOfSets");
	removeElement("humansizelabel");
	removeElement("bglabel");
	removeElement("shadowlabel");
	document.getElementById('Algorithm1.Human.Size').type='hidden';
	document.getElementById('Algorithm1.Threshold.Background').type='hidden';
	document.getElementById('Algorithm1.Threshold.Shadow').type='hidden';
	
   }
}

function hideVideoAnnotations()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "Admin") )
   { 
    removeElement("annotations");
   }
}

function hideVideoRecParameters()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "Admin") )
   { 
	removeElement("vrec_senderip");
	removeElement("vrec_senderport");
	removeElement("vrec_receiverport");
	removeElement("serialid_label");
	removeElement("serialid_radios");
	removeElement("period");
	document.getElementById('Network.Data.CountingPeriod').type='hidden';
	document.getElementById('Network.VideoRecord.SenderIp').type='hidden';
	document.getElementById('Network.VideoRecord.SenderPort').type='hidden';
	document.getElementById('Network.VideoRecord.ReceiverPort').type='hidden';
	document.getElementById("Network.Sender.CustomerID").disabled=true;
	document.getElementById("Network.Sender.DeviceID").disabled=true;
   }
}

function hideWebParameters()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "Admin") )
   { 
	removeElement("superadminuser");
	removeElement("superadminpass");
	removeElement("adminuser");
	removeElement("adminpass");
	removeElement("middleuser");
	removeElement("middlepass");
	removeElement("lowuser");
	removeElement("lowpass");
	document.getElementById('USERS.Admin').type='hidden';
	document.getElementById('USERS.Adminpass').type='hidden';
	document.getElementById('USERS.Root').type='hidden';
	document.getElementById('USERS.Rootpass').type='hidden';
	document.getElementById('USERS.Middle').type='hidden';
	document.getElementById('USERS.Middlepass').type='hidden';
	document.getElementById('USERS.Low').type='hidden';
	document.getElementById('USERS.Lowpass').type='hidden';
   }
}

function hideIntervalParameters()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "LowLevel")  || (current == "Admin") )
   { 
	removeElement("addinterval");
	removeElement("deleteinterval");
	removeElement("days");
   }
}

function hideLiveStreamParameters()
{
   var current = readCookie("userlevel");
   if( (current == "MiddleLevel") || (current == "LowLevel")  || (current == "Admin") )
   { 
	removeElement("fps");
   }
}