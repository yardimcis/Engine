var parameter = 
{
  // Backend URL, string.
  // 'http://backend.address.com' or '' if backend is the same as frontend
  backendUrl: '',
};

var timeoutCalculated;
var querytime;
var lastquerytime;
var xmlDoc=null;
var languageType=null;
var webPort=null;
var mean=null;

function getLanguageFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","../Settings/Language.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("Root");
		languageType = x[0].getElementsByTagName("Language")[0].childNodes[0].nodeValue;
		return	languageType;		
	}
}
function getPortFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","../Settings/WebServer.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("HTTP");
		webPort = x[0].getElementsByTagName("Port")[0].childNodes[0].nodeValue;
		return	webPort;		
	}
}
function getMeanFromXML()
{
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","Settings/ImageProcessing.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("Root");
		mean = x[0].getElementsByTagName("Mean")[0].childNodes[0].nodeValue;
		return	mean;		
	}
}
$(function(){
    languageType = getLanguageFromXML();
});
 
 function getLangResult(xmlTag)
 {
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp2=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp2=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(languageType == "TR")
		xmlhttp2.open("GET","../Settings/LanguageTR.xml",false);
	else
		xmlhttp2.open("GET","../Settings/LanguageEN.xml",false);
		
	xmlhttp2.send();
	xmlDoc2=xmlhttp2.responseXML;
	
	xmlDoc2.async=false;
	return xmlDoc2.getElementsByTagName(xmlTag)[0].childNodes[0].nodeValue;
	
 }

$('.send_data').live("click",function() {
	// check form
	if( $("#parameter_form").valid() )	
	{
		var dataver = $('#parameter_form').serialize();	
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				var res = dataver.split("ParameterTreeID=");
				if(res[1]!="1020")
					parameter.updated( "refresh_page" );
			},
			error: function() 
			{	
				window.top.mainFrame.jQuery.facebox( getLangResult("SendFail") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
	else
	{
		window.top.mainFrame.jQuery.facebox( getLangResult("WrongInput") );
	}
});

$('.send_data_remote_server').live("click",function() {
	// check form
	if( $("#parameter_form").valid() )	
	{
		var dataver = $('#parameter_form').serialize();	
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				var answer;
				answer = confirm(getLangResult("Restart"))
				
				if (answer)
				{		
					$.ajax
					({
						dataType: 'json',
						url: '/ajax/get_messages',
						data: "ParameterTreeID=20",
						success: function() 
						{	
							window.top.mainFrame.jQuery.facebox( getLangResult("WillRestart"));	
							webPort = getPortFromXML();
							var directFunction = function() {navigate("http://"+location.hostname+":"+webPort)};
							setTimeout( directFunction, 25 * 1000 );
						},
						error: function() 
						{				
							window.top.mainFrame.jQuery.facebox( getLangResult("RestartError") );
							setTimeout(refresh_all(),2000);
						},
					});
				}
				else
					parameter.updated( "refresh_page" );
			},
			error: function() 
			{	
				window.top.mainFrame.jQuery.facebox( getLangResult("SendFail") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
	else
	{
		window.top.mainFrame.jQuery.facebox( getLangResult("WrongInput") );
	}
});

$('.send_img_proc').live("click",function() {
	// check form
	if( document.getElementById('Height').value > 0 )
	{
		if( $("#parameter_form").valid() )	
		{
			var dataver = $('#parameter_form').serialize();	
			$.ajax({
				dataType: 'json',
				url: '/ajax/get_messages',
				data: dataver,
				success: function() 
				{
					parameter.updated( "refresh_page" );
				},
				error: function() 
				{	
					window.top.mainFrame.jQuery.facebox( getLangResult("SendFail") );
					setTimeout(refresh_all(),2000);
				},
			});
		}
		else
		{
			window.top.mainFrame.jQuery.facebox( getLangResult("WrongInput") );
		}
	}
	else window.top.mainFrame.jQuery.facebox( getLangResult("ZeroHeight") );
});

function get_data( TreeID ) 
{	
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_data',
		data: "ParameterTreeID=" + TreeID,
		success: function( Data ) 
		{
			// clear validation
			$("#parameter_form").validate().resetForm();
			
			// get parameter name list
			var leaf_nodes = get_leaf_nodes( Data.Root, "" );			
			
			// set each item
			for( var i = 0; i < leaf_nodes.length; i++ )
			{
				var Item = $("input[name=" + leaf_nodes[ i ] +"]");		
				var JsonName = "Data.Root." + leaf_nodes[ i ];				
				
				Item.val( eval( JsonName ) );
			}					
		},
		error: function() 
		{					
			window.top.mainFrame.jQuery.facebox( getLangResult("ReadFail") );
			setTimeout(refresh_all(),2000);
		},
	});
}

function get_leaf_nodes( JsonArray, Prefix )
{
	var ret = [];	
	
	$.each( JsonArray, function( key, val ) 
	{
		var NewPrefix = ( Prefix == "" ) ? key : Prefix + "." + key;		
		
		if( typeof( val ) == 'object' )
		{			
			var leaf_nodes_list = get_leaf_nodes( val, NewPrefix );			
			ret = ret.concat( leaf_nodes_list );			
		}
		else
		{
			ret.push( NewPrefix )			
		}
	});
	
	return ret;
}

$('.annotations').live("click",function() 
{	
	// create annotations data
	var DataString = "ParameterTreeID=1011";
	$.each( $('.annotations'), function( index, value )
	{
		DataString += "&Annotations." + $(this).attr( 'name' ) + "=";
		if( $(this).attr( 'checked' ) == true )
		{
			DataString += "true";
		}
		else
		{
			DataString += "false";
		}
	});	
	
	$.ajax
	({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: DataString,
		success: function(data) 
		{				
		},
		error: function() 
		{			
			setTimeout(refresh_all(),1000);
		},
	});			
});

$('.stopdsp').live("click",function() 
{	
	var DataString;
	var ButtonValue;
	ButtonValue = document.getElementById("stopdsp").value;
	
	if((ButtonValue == "Görüntü İşlemeyi Durdur") || (ButtonValue == "Stop Image Processing"))
	{
		document.getElementById("stopdsp").value = "Görüntü İşlemeyi Başlat";
		DataString = "ParameterTreeID=32";
	}
	else
	{
		document.getElementById("stopdsp").value = "Görüntü İşlemeyi Durdur";
		DataString = "ParameterTreeID=33";
	}
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: DataString,
		success: function() 
		{
			/*window.top.mainFrame.jQuery.facebox( getLangResult("Rebooted") );
			
			setTimeout( "refresh_all()", 70 * 1000 );*/
		},
		error: function() 
		{
			setTimeout(refresh_all(),2000);
		},
	});
});

$('.restart').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("Restart"))
	
	if (answer)
	{		
		$.ajax
		({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=20",
			success: function() 
			{	
				window.top.mainFrame.jQuery.facebox( getLangResult("WillRestart"));	
				webPort = getPortFromXML();
				var directFunction = function() {navigate("http://"+location.hostname+":"+webPort)};
				setTimeout( directFunction, 25 * 1000 );
			},
			error: function() 
			{				
				window.top.mainFrame.jQuery.facebox( getLangResult("RestartError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}		
});

$('.kick').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("KickUser"));
	if (answer)
	{		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=24",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Kicked") );
				setTimeout( "refresh_all()", 2 * 1000 );				
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("KickError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}		
});

$('.inc_in').live("click",function() 
{	
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=36",
		success: function() 
		{				
		},
		error: function() 
		{
			window.top.mainFrame.jQuery.facebox( "Error" );
		},
	});
		
});

$('.mean').live("click",function() 
{	
	var answer = 0;
	var firstMeanSet = 0;
	getMeanFromXML();
	
	if(mean > 0)
		answer = confirm(getLangResult("Mean"));
	else
		firstMeanSet = 1;
	
	if (answer || firstMeanSet)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=41",
			success: function() 
			{				
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( "Error" );
			},
		});
	}	
});


$('.inc_out').live("click",function() 
{	
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=37",
		success: function() 
		{				
		},
		error: function() 
		{
			window.top.mainFrame.jQuery.facebox( "Error" );
		},
	});
		
});

$('.inc_str').live("click",function() 
{	
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=38",
		success: function() 
		{				
		},
		error: function() 
		{
			window.top.mainFrame.jQuery.facebox( "Error" );
		},
	});
		
});

$('.refresh').live("click",function() 
{	
		
	$.ajax({
		dataType: 'json',
		url: '/ajax/get_messages',
		data: "ParameterTreeID=39",
		success: function() 
		{			
			setTimeout(refresh_current(),200);
		},
		error: function() 
		{
			window.top.mainFrame.jQuery.facebox( "Error" );
		},
	});
		
});

$('.turkish').live("click",function() 
{	

	if(languageType != "TR")
	{//if user tries to set the same language with the active one, do nothing
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=29",
			success: function() 
			{		
							
				window.top.mainFrame.jQuery.facebox( "Lütfen bekleyiniz. / Please wait." );				
				setTimeout( "refresh_all()", 15 * 1000 );
				
			},
			error: function() 
			{				
				window.top.mainFrame.jQuery.facebox( "Hata! / Error!" );
				setTimeout(refresh_all(),2000);
			},
		});	
	}
});

$('.english').live("click",function() 
{	
	if(languageType != "EN")
	{//if user tries to set the same language with the active one, do nothing
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=30",
			success: function() 
			{				
							
				window.top.mainFrame.jQuery.facebox( "Lütfen bekleyiniz. / Please wait." );				
				setTimeout( "refresh_all()", 15 * 1000 );
				
			},
			error: function() 
			{				
				window.top.mainFrame.jQuery.facebox( "Hata! / Error!" );
				setTimeout(refresh_all(),2000);
			},
		});	
	}
});

$('.block').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("Block"))
	
	if (answer)
	{		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=25",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Blocked") );
				setTimeout( "refresh_all()", 2 * 1000 );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("BlockFail") );
				setTimeout(refresh_all(),2000);
			},
		});
	}		
	
});

$('.allow').live("click",function() 
{	
	var answer;
		answer = confirm(getLangResult("Allow"))
	if (answer)
	{		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=26",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Allowed") );
				setTimeout( "refresh_all()", 2 * 1000 );
			},
			error: function() 
			{
					window.top.mainFrame.jQuery.facebox( getLangResult("AllowFail") );
					setTimeout(refresh_all(),2000);
			},
		});
	}		
	
});

$('.logout').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("LogoutConfirm"))
	
	if (answer)
	{		
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=28",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Loggedout") );
				setTimeout( "refresh_all()", 3 * 1000 );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("LogoutError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}		
	
});

$('.reboot').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("Reboot"))
	
	if (answer)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=21",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Rebooted") );
				
				setTimeout( "refresh_all()", 70 * 1000 );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("RebootError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
});

$('.save_configuration').live("click",function()
{
	$.ajax(
	{
		dataType: 'html',
		timeout: 10000, 
		url: '/save/configuration',
		data: "",
		success: function( data ) 
		{
			if( data != "" )  
			{
				window.location.href = data;
			}
			else			
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("SaveConfig") );
			}
		},
		error: function(data) 
		{
			window.top.mainFrame.jQuery.facebox( getLangResult("SaveConfig") );
		}
	});
}); 

$('.save_video').live("click",function()
{
	$.ajax(
	{
		dataType: 'html',
		timeout: 10000, 
		url: '/save/video',
		data: "",
		success: function( data ) 
		{
			if( data != "" )  
			{
				window.location.href = data;
			}
			else			
			{
			}
		},
		error: function(data) 
		{
		}
	});
}); 


$('.dsp_reset').live("click",function() 
{	
	var answer;
	answer = confirm(getLangResult("Dspreset"))
	
	if (answer)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=23",
			success: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("Dspresetted") );		
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("DspresetError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
});

$('.new_user_send').live("click",function() 
{	
	var dataver = $('#new_user').serialize();
	
	var queryArray = dataver.split('&'); //i.e. ParameterTreeID=34&NewUserPassword=bb&NewUserPassword2=bb
	var newPass1 = queryArray[1].split('=')[1];
	var newPass2 = queryArray[2].split('=')[1];
	if(newPass1 == newPass2)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				parameter.updated( "application_restart" );
			},
			error: function() 
			{
				if(languageType == "TR")
					document.getElementById("waitforreload").innerHTML = "Lütfen 15 saniye bekleyiniz...";
				else if(languageType == "EN")
					document.getElementById("waitforreload").innerHTML = "Please wait 15 seconds...";
				setTimeout("window.location.reload( true )",15000);
			},
		});
	}
	else
	{
		if(languageType == "TR")
			document.getElementById("waitforreload").innerHTML = "Girdiğiniz şifreler aynı olmalıdır";
		else if(languageType == "EN")
			document.getElementById("waitforreload").innerHTML = "Passwords do not match";
			
	}
	
});

$('.tcp_send').live("click",function() 
{	
	// check form
	if( $("#tcp_settings").valid() )	
	{
		var dataver = $('#tcp_settings').serialize();	
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				parameter.updated( "system_restart" );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("TcpSendError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
	else
	{
		window.top.mainFrame.jQuery.facebox(  getLangResult("WrongInput") );
	}
});


$('.wifi_send').live("click",function() 
{
	// check form
	if( $("#wifi_settings").valid() )	
	{
		var dataver = "ParameterTreeID=40&WifiNetwork="+document.getElementById("WifiNetwork").value+"&WifiPassword="+document.getElementById("WifiPassword").value;
		dataver = dataver.replace(" ","<SpaceChar>");

		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				parameter.updated( "system_restart" );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("TcpSendError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
	else
	{
		window.top.mainFrame.jQuery.facebox(  getLangResult("WrongInput") );
	}
});


$('.3g_send').live("click",function() 
{
	// check form
	if( $("#3g_settings").valid() )	
	{
		var dataver = $('#3g_settings').serialize();
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: dataver,
			success: function() 
			{
				parameter.updated( "system_restart" );
			},
			error: function() 
			{
				window.top.mainFrame.jQuery.facebox( getLangResult("TcpSendError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
	else
	{
		window.top.mainFrame.jQuery.facebox(  getLangResult("WrongInput") );
	}
});

$('.tcp_reset').live("click",function() 
{	
	var answer;
	answer = confirm( getLangResult("TcpReset") + 
						  "\n" +
						  "IP:      192.168.1.26\n" +
						  "Netmask: 255.255.255.0\n" +
						  "Gateway: 192.168.1.10\n" );
	
	if(answer)
	{
		$.ajax({
			dataType: 'json',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=22",
			success: function() 
			{		
				window.top.mainFrame.jQuery.facebox( getLangResult("TcpWillReset") );
				webPort = getPortFromXML();
				var NavigateFunction = function() {navigate("http://192.168.1.26:"+webPort)};
				setTimeout( NavigateFunction, 70 * 1000 );
			},
			error: function() 
			{				
				window.top.mainFrame.jQuery.facebox( getLangResult("TcpResetError") );
				setTimeout(refresh_all(),2000);
			},
		});
	}
});

function live_image_annotation_check() {
	
	$.ajax
	({
		dataType: 'json',
		url: '/ajax/get_data',
		data: "ParameterTreeID=1011",
		success: function(data) 
		{													
			if( data.Root.Annotations != null )
			{
				$.each( data.Root.Annotations, function(key, val) 
				{								
					if( val == "true" ) $( "[name=" + key + "]" ).attr( 'checked', true );
					else if( val == "false" ) $( "[name=" + key + "]" ).attr( 'checked', false );				
				});
			}
		},
		error: function() 
		{		
			setTimeout(refresh_all(),2000);		
		},
	});		
}

function kontrolet() {
	
	$.ajax
	({
		dataType: 'json',
		url: '/ajax/get_data',
		data: "ParameterTreeID=1011",
		success: function(data) 
		{													
			$.each( data.Root.Annotations, function(key, val) 
			{								
				if( val == "true" ) $( "[name=" + key + "]" ).attr( 'checked', true );
				else if( val == "false" ) $( "[name=" + key + "]" ).attr( 'checked', false );				
			});
		},
		error: function() 
		{			
		},
	});		
}

function updateUserCount() {
    
    $.ajax
		({
			dataType: 'html',
			url: '/ajax/get_messages',
			data: "ParameterTreeID=27",
			success: function(data) 
			{		
			   $("#usercount").text(data);
			},
			error: function() 
			{
				alert( "Aktif kullanıcı sayısı verisi alınamadı" );
			}
		});
}


parameter.updated = function( Action ) 
{	
	var confirm_text;
	var alert_text1;	
	var alert_text2;	
	var refresh_timeout;
	var id;
	var user_interaction = true;
	var is_system_restart = false;
	if( Action == "system_restart" )
	{
		is_system_restart = true;
		confirm_text = getLangResult("ConfirmText");					   
		alert_text1 =  getLangResult("AlertText1");
		alert_text2 =  getLangResult("AlertText2");
		
		refresh_timeout = 70 * 1000;
		id = "21";
	}
	else if( Action == "application_restart" )
	{
		confirm_text = getLangResult("AppRestart");	
		alert_text1 = getLangResult("AppText1");	
		alert_text2 = getLangResult("AppText2");	
		
		refresh_timeout = 25 * 1000;
		id = "20";
	}
	else if( Action == "refresh_page" )
	{
		user_interaction = false;
		window.top.mainFrame.jQuery.facebox( getLangResult("Refresh") );
		
		setTimeout( "refresh_current()", 5 * 1000 );
	}
	
	if(is_system_restart)
	{
		var answer = confirm( confirm_text )
		if( answer )
		{		
			$.ajax
			({
				dataType: 'json',
				url: '/ajax/get_messages',
				data: "ParameterTreeID=" + id,
				success: function() 
				{		
					window.top.mainFrame.jQuery.facebox( alert_text1 );
					webPort = getPortFromXML();
					var NavigateFunction = function() {navigate("http://"+$("#IP").val()+":"+webPort)};
					setTimeout( NavigateFunction, refresh_timeout );
				},
				error: function() 
				{
					alert( alert_text2 );
				},
			});
		}		
	}
	else if( user_interaction )
	{
		var answer = confirm( confirm_text )
		if( answer )
		{		
			$.ajax
			({
				dataType: 'json',
				url: '/ajax/get_messages',
				data: "ParameterTreeID=" + id,
				success: function() 
				{				
					window.top.mainFrame.jQuery.facebox( alert_text1 );
					setTimeout( "refresh_current()", refresh_timeout );
				},
				error: function() 
				{
					alert( alert_text2 );
				},
			});
		}		
	}
};

function reload_iframe( iframe_id )
{
	document.getElementById( iframe_id ).contentWindow.location.reload( true );
}

function navigate_iframe( iframe_id, newURL )
{
	document.getElementById( iframe_id ).contentWindow.location = newURL;
}

function refresh_current()
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    window.location.reload( true );
}

function refresh_all()
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    top.location.reload( true );
}

function navigate( newUrl )
{
    //  This version of the refresh function will be invoked
    //  for browsers that support JavaScript version 1.2
    //
    
    //  The argument to the location.reload function determines
    //  if the browser should retrieve the document from the
    //  web-server.  In our example all we need to do is cause
    //  the JavaScript block in the document body to be
    //  re-evaluated.  If we needed to pull the document from
    //  the web-server again (such as where the document contents
    //  change dynamically) we would pass the argument as 'true'.
    //  
    top.location = newUrl;
}
