/*
 * jQuery jclock - Clock plugin - v 1.2.0
 * http://plugins.jquery.com/project/jclock
 *
 * Copyright (c) 2007-2008 Doug Sparling <http://www.dougsparling.com>
 * Licensed under the MIT License:
 *   http://www.opensource.org/licenses/mit-license.php
 */
var xmlDoc=null;
var xmlDoc2=null;
var languageType=null;
var mon,sun,tue,wed,thu,fri,sat;
var jan,feb,mar,apr,may,jun,jul,aug,sep,oct,dec,nov;

function getLanguage()
{
	
	if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	}
	
	xmlhttp.open("GET","../Settings/Language.xml",false);
	xmlhttp.send();
	xmlDoc=xmlhttp.responseXML;
	if (xmlDoc!=null)
	{
		xmlDoc.async=false;
		var x=xmlDoc.getElementsByTagName("Root");
		languageType = x[0].getElementsByTagName("Language")[0].childNodes[0].nodeValue;
		return	languageType;		
	}
}

$(function(){
	languageType = getLanguage();  
    if (window.XMLHttpRequest)
	{// code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp2=new XMLHttpRequest();
	}
	else
	{// code for IE6, IE5
		xmlhttp2=new ActiveXObject("Microsoft.XMLHTTP");
	}
	if(languageType == "TR")
		xmlhttp2.open("GET","../Settings/LanguageTR.xml",false);
	else
		xmlhttp2.open("GET","../Settings/LanguageEN.xml",false);
		
	xmlhttp2.send();
	xmlDoc2=xmlhttp2.responseXML;
	if (xmlDoc2!=null)
	{
		xmlDoc2.async=false;
		sun = xmlDoc2.getElementsByTagName("Sunday")[0].childNodes[0].nodeValue;
		mon = xmlDoc2.getElementsByTagName("Monday")[0].childNodes[0].nodeValue;
		tue = xmlDoc2.getElementsByTagName("Tuesday")[0].childNodes[0].nodeValue;
		wed = xmlDoc2.getElementsByTagName("Wednesday")[0].childNodes[0].nodeValue;
		thu = xmlDoc2.getElementsByTagName("Thursday")[0].childNodes[0].nodeValue;
		fri = xmlDoc2.getElementsByTagName("Friday")[0].childNodes[0].nodeValue;
		sat = xmlDoc2.getElementsByTagName("Saturday")[0].childNodes[0].nodeValue;
		
		jan = xmlDoc2.getElementsByTagName("Jan")[0].childNodes[0].nodeValue;
		feb = xmlDoc2.getElementsByTagName("Feb")[0].childNodes[0].nodeValue;
		mar = xmlDoc2.getElementsByTagName("Mar")[0].childNodes[0].nodeValue;
		apr = xmlDoc2.getElementsByTagName("Apr")[0].childNodes[0].nodeValue;
		may = xmlDoc2.getElementsByTagName("May")[0].childNodes[0].nodeValue;
		jun = xmlDoc2.getElementsByTagName("Jun")[0].childNodes[0].nodeValue;
		jul = xmlDoc2.getElementsByTagName("Jul")[0].childNodes[0].nodeValue;
		aug = xmlDoc2.getElementsByTagName("Aug")[0].childNodes[0].nodeValue;
		sep = xmlDoc2.getElementsByTagName("Sep")[0].childNodes[0].nodeValue;
		oct = xmlDoc2.getElementsByTagName("Oct")[0].childNodes[0].nodeValue;
		nov = xmlDoc2.getElementsByTagName("Nov")[0].childNodes[0].nodeValue;
		dec = xmlDoc2.getElementsByTagName("Dec")[0].childNodes[0].nodeValue;
	}
});


(function($) {

  $.fn.jclock = function(options) {
    var version = '1.2.0';

    // options
    var opts = $.extend({}, $.fn.jclock.defaults, options);
         
    return this.each(function() {
      $this = $(this);
      $this.timerID = null;
      $this.running = false;

      var o = $.meta ? $.extend({}, opts, $this.data()) : opts;
      
      $this.utc = o.utc;
      $this.utc_offset = o.utc_offset;

      $this.css({
        fontFamily: o.fontFamily,
        fontSize: o.fontSize,
        backgroundColor: o.background,
        color: o.foreground
      });

      $.fn.jclock.startClock($this);

    });
  };
       
  $.fn.jclock.startClock = function(el) {
    $.fn.jclock.stopClock(el);
    $.fn.jclock.displayTime(el);
  }
  $.fn.jclock.stopClock = function(el) {
    if(el.running) {
      clearTimeout(el.timerID);
    }
    el.running = false;
  }
  $.fn.jclock.displayTime = function(el) {
    var time = $.fn.jclock.getTime(el);
    el.html(time);
    el.timerID = setTimeout(function(){$.fn.jclock.displayTime(el)},1000);
  }
  $.fn.jclock.getTime = function(el) {
    var now = new Date();
    var hours, minutes, seconds;
	var days, months, years;	

    if(el.utc == true) {
      var localTime = now.getTime();
      var localOffset = now.getTimezoneOffset() * 60000;
      var utc = localTime + localOffset;
      var utcTime = utc + (3600000 * el.utc_offset);
      now = new Date(utcTime);
    }
    
	var dayarray=new Array(sun,mon,tue,wed,thu,fri,sat);
	var montharray=new Array(jan,feb,mar,apr,may,jun,jul,aug,sep,oct,nov,dec);
	
	hours = now.getHours();
    minutes = now.getMinutes();
    seconds = now.getSeconds();
	
	days = now.getDate();
    months = now.getMonth();
    years = now.getFullYear();
		
	hours   = ((hours <  10) ? "0" : "") + hours;
    minutes = ((minutes <  10) ? "0" : "") + minutes;
    seconds = ((seconds <  10) ? "0" : "") + seconds;
	
	days   = ((days <  10) ? "0" : "") + days;
    months = ((minutes <  10) ? "0" : "") + months;
    years = ((years <  10) ? "0" : "") + years;
	years = ((years <  100) ? "0" : "") + years;
	years = ((years <  1000) ? "0" : "") + years;

    var timeNow = days + " " + montharray[ now.getMonth() ] + " " + years + " " + dayarray[ now.getDay() ] + " " + hours + ":" + minutes + ":" + seconds;
    
    return timeNow;
  };
       
  // plugin defaults
  $.fn.jclock.defaults = {
	turkishLocale: false,
	utc: false,
    fontFamily: '',
    fontSize: '',
    foreground: '',
    background: '',
    utc_offset: 0
  };

})(jQuery);
